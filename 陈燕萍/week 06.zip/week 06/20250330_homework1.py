# olivetti_rnn_classifier.py
import os
import torch
import torch.nn as nn
import numpy as np
from sklearn.datasets import fetch_olivetti_faces
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset
from torch.utils.tensorboard import SummaryWriter
import matplotlib.pyplot as plt

# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
os.makedirs("saved_models", exist_ok=True)

# 加载数据
faces = fetch_olivetti_faces()
X = faces.images.astype(np.float32)  # (400, 64, 64)
y = faces.target
X_seq = X.reshape(-1, 64, 64)
X_train, X_test, y_train, y_test = train_test_split(X_seq, y, test_size=0.2, stratify=y, random_state=42)
X_train_tensor = torch.tensor(X_train)
X_test_tensor = torch.tensor(X_test)
y_train_tensor = torch.tensor(y_train).long()
y_test_tensor = torch.tensor(y_test).long()
train_loader = DataLoader(TensorDataset(X_train_tensor, y_train_tensor), batch_size=32, shuffle=True)
test_loader = DataLoader(TensorDataset(X_test_tensor, y_test_tensor), batch_size=32)

# 模型类
class RNNClassifier(nn.Module):
    def __init__(self, rnn_type='RNN'):
        super().__init__()
        rnn_cls = {'RNN': nn.RNN, 'LSTM': nn.LSTM, 'GRU': nn.GRU}[rnn_type]
        self.rnn = rnn_cls(input_size=64, hidden_size=128, num_layers=2, batch_first=True)
        self.fc = nn.Linear(128, 40)
    def forward(self, x):
        out, _ = self.rnn(x)
        return self.fc(out[:, -1, :])

# 训练和评估
def train_and_evaluate(rnn_type):
    print(f"\n=== Training {rnn_type} ===")
    model = RNNClassifier(rnn_type).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    writer = SummaryWriter(log_dir=f"runs/{rnn_type}")
    train_acc_list, test_acc_list, train_loss_list = [], [], []

    for epoch in range(20):
        model.train()
        correct_train, total_loss = 0, 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * X_batch.size(0)
            correct_train += (outputs.argmax(1) == y_batch).sum().item()

        avg_train_loss = total_loss / len(train_loader.dataset)
        train_acc = correct_train / len(train_loader.dataset)
        train_loss_list.append(avg_train_loss)
        train_acc_list.append(train_acc)

        model.eval()
        correct_test = 0
        with torch.no_grad():
            for X_batch, y_batch in test_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                outputs = model(X_batch)
                correct_test += (outputs.argmax(1) == y_batch).sum().item()
        test_acc = correct_test / len(test_loader.dataset)
        test_acc_list.append(test_acc)

        writer.add_scalar('Loss/Train', avg_train_loss, epoch)
        writer.add_scalar('Accuracy/Train', train_acc, epoch)
        writer.add_scalar('Accuracy/Test', test_acc, epoch)
        print(f"Epoch {epoch+1}/10: Loss={avg_train_loss:.4f}, Train Acc={train_acc:.4f}, Test Acc={test_acc:.4f}")

    writer.close()
    torch.save(model.state_dict(), f"saved_models/{rnn_type}_classifier.pth")
    return train_acc_list, test_acc_list

# 主训练流程
results = {}
for model_type in ['RNN', 'LSTM', 'GRU']:
    results[model_type] = train_and_evaluate(model_type)

# 准确率图
plt.figure(figsize=(10, 6))
for model_type, (_, test_acc) in results.items():
    plt.plot(test_acc, label=f"{model_type} Test Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.title("RNN vs LSTM vs GRU - Olivetti Face Classification")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("tensorboard_accuracy_comparison.png")
plt.show()