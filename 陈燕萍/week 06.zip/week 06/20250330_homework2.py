import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler
from torch.utils.tensorboard import SummaryWriter
import matplotlib.pyplot as plt

# 设置设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 天气数据集自定义 Dataset
class WeatherDataset(Dataset):
    def __init__(self, series, seq_len=30, pred_len=1):
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.series = series
        self.X, self.y = self.create_sequences(series)

    def create_sequences(self, data):
        X, y = [], []
        for i in range(len(data) - self.seq_len - self.pred_len + 1):
            X.append(data[i:i+self.seq_len])
            y.append(data[i+self.seq_len:i+self.seq_len+self.pred_len])
        return np.array(X), np.array(y)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return torch.tensor(self.X[idx], dtype=torch.float32).unsqueeze(-1), \
               torch.tensor(self.y[idx], dtype=torch.float32)

# 简单 RNN 模型
class RNNPredictor(nn.Module):
    def __init__(self, hidden_size=64, num_layers=1, pred_len=1):
        super().__init__()
        self.rnn = nn.RNN(input_size=1, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, pred_len)

    def forward(self, x):
        out, _ = self.rnn(x)
        out = self.fc(out[:, -1, :])
        return out

# 训练和测试函数
def train_model(model, train_loader, test_loader, pred_len, run_name='weather_rnn'):
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    writer = SummaryWriter(log_dir=f"runs/{run_name}")

    train_losses, test_losses = [], []

    for epoch in range(10):
        model.train()
        total_train_loss = 0
        for x_batch, y_batch in train_loader:
            x_batch, y_batch = x_batch.to(device), y_batch.to(device)
            optimizer.zero_grad()
            outputs = model(x_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            total_train_loss += loss.item()

        avg_train_loss = total_train_loss / len(train_loader)
        train_losses.append(avg_train_loss)

        model.eval()
        total_test_loss = 0
        with torch.no_grad():
            for x_batch, y_batch in test_loader:
                x_batch, y_batch = x_batch.to(device), y_batch.to(device)
                outputs = model(x_batch)
                loss = criterion(outputs, y_batch)
                total_test_loss += loss.item()

        avg_test_loss = total_test_loss / len(test_loader)
        test_losses.append(avg_test_loss)

        writer.add_scalar("Loss/Train", avg_train_loss, epoch)
        writer.add_scalar("Loss/Test", avg_test_loss, epoch)
        print(f"Epoch {epoch+1}: Train Loss={avg_train_loss:.4f}, Test Loss={avg_test_loss:.4f}")

    writer.close()
    torch.save(model.state_dict(), f"weather_model_{pred_len}day.pth")
    return train_losses, test_losses

# 主函数
def main():
    # 加载数据
    df = pd.read_csv("c:/Users/stephanie.chen/Desktop/Desktop/PA/WASHZ/Personal/ST/2025/八斗学院深度学习2025/作业/week 06/Summary of Weather.csv")
    df["MaxTemp"] = pd.to_numeric(df["MaxTemp"], errors="coerce")
    df = df[["MaxTemp"]].dropna()

    # 标准化
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df.values).flatten()

    # 创建数据集
    seq_len = 30
    batch_size = 32

    for pred_len in [1, 5]:
        dataset = WeatherDataset(scaled, seq_len, pred_len)
        train_size = int(len(dataset) * 0.8)
        test_size = len(dataset) - train_size
        train_dataset, test_dataset = torch.utils.data.random_split(dataset, [train_size, test_size])

        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        test_loader = DataLoader(test_dataset, batch_size=batch_size)

        model = RNNPredictor(pred_len=pred_len).to(device)
        train_model(model, train_loader, test_loader, pred_len, run_name=f"RNN_{pred_len}day")

main()